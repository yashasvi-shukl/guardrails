import os
import yaml

def load_config(config_path):
    """Load configuration from the YAML file."""
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    
    # Set environment variable for OpenAI API Key
    os.environ['OPENAI_API_KEY'] = config['model']['OPENAI_API_KEY']
    
    return config
