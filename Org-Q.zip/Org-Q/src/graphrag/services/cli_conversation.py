import os
import requests

# Define the base URLs for the endpoints
UPDATE_SKILLS_URL = "http://127.0.0.1:5000/get_skills"
QUERY_NEO4J_URL = "http://127.0.0.1:8000/query"

def update_skills(folder_path, employee_id, employee_name):
    """Call the update_skills endpoint."""
    data = {
        "folder_path": folder_path,
        "employee_id": int(employee_id),
        "ename": employee_name
    }
    try:
        response = requests.post(UPDATE_SKILLS_URL, json=data)
        if response.status_code == 200:
            print(f"\nUpdated skills: {response.json()}\n")
        else:
            print("Error:", response.json())
    except Exception as e:
        print(f"Failed to connect to update_skills endpoint: {e}")

def query_neo4j(query):
    """Call the query_neo4j endpoint."""
    data = {"query": query}
    try:
        response = requests.post(QUERY_NEO4J_URL, json=data)
        if response.status_code == 200:
            print(f"Query result: {response.json()}\n")
        else:
            print("Error:", response.json())
    except Exception as e:
        print(f"Failed to connect to query_neo4j endpoint: {e}")

def main():
    print("***Welcome! You can interact with the Neo4j system.***")

    while True:
        user_input = input("\nEnter a directory path (for updating skills) or a query (for querying Neo4j), or 'exit' to quit: ")

        if user_input.lower() == "exit":
            print("Goodbye!")
            break

        if os.path.isdir(user_input):
            employee_id = input("Enter the Employee ID: ")
            employee_name = input("Enter the Employee Name: ")
            update_skills(user_input, employee_id, employee_name)
        else:
            query_neo4j(user_input)

if __name__ == "__main__":
    main()
