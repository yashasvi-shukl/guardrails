from flask import jsonify, request
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from src.graphrag.processors.utilities.neo4j_utils import Neo4jConnection
from src.graphrag.processors.update_mentors.update_mentor import MentorUpdater
from src.graphrag.processors.recommender.recommender import MentorRecommender
from src.graphrag.processors.chains.chains import CypherChainBuilder
from src.graphrag.processors.update_skills.update_employee_skills import SkillExtractorApp

def create_router_chain(llm, config):
    """
    Create the router chain for classifying query intents.

    Parameters:
    - llm: An instance of a language model (e.g., ChatOpenAI).

    Returns:
    - A router chain configured to classify query intents.
    """
    router_prompt = PromptTemplate.from_template(template = config['ROUTER_TEMPLATE'])

    return router_prompt | llm

def create_routes(app, config):
    """
    Create and register routes for the Flask application.

    Parameters:
    - app: The Flask application instance.
    - config: Configuration dictionary containing Neo4j and other settings.
    """
    # Initialize the Neo4j connection
    try:
        db = Neo4jConnection(config['Neo4j']['NEO4J_URI'], config['Neo4j']['NEO4J_USER'], config['Neo4j']['NEO4J_PASSWORD'])
        mentor_updater = MentorUpdater(driver=db.driver, config=config)
    except Exception as e:
        raise RuntimeError(f"Failed to initialize database connections: {str(e)}")

    print(f"Schema: {db.graph.schema}")
    # Initialize the LLM for intent classification
    llm = ChatOpenAI(model=config['model'].get('model_name'), temperature=0)
    # Initialize the Cypher chain
    try:
        schema_properties = db.fetch_schema_properties(config=config)
        property_types = db.convert_to_markdown_table(schema_properties)
        print(f"Properties Types: \n{property_types}")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch schema property types:{str(e)}")
    
    cypher_builder = CypherChainBuilder(llm = llm, graph=db.graph, config=config)
    chain = cypher_builder.create_cypher_chain()

    # print("Cypher Prompt: ", cypher_builder.cypher_prompt)

    # Initialize the router chain
    router_chain = create_router_chain(llm, config)

    #Initialize the MentorRecommender
    mentor_recommender = MentorRecommender(driver = db.driver, graph=db.graph, llm=llm, config=config)

    skill_extractor = SkillExtractorApp(config=config,
                                        llm=llm,
                                        graph=db.graph,
                                        driver= db.driver)
    
    @app.route('/query', methods=['POST'])
    def query_neo4j():
        """
        Classifies the query and fetches results accordingly.

        Request JSON:
        - query: The user query to classify and execute.

        Returns:
        - JSON response containing the query results or an error message.
        """
        data = request.json
        query = data.get('query')
        employee_id = data.get('employee_id') if data.get('employee_id') else 5
        # print(f"Employee id: {employee_id}")
        if not query:
            return jsonify({"error": "Query not provided"}), 400

        try:
            category = router_chain.invoke(query).content
            # print(f"Category: {category}")
            if "recommend_mentor" in category:
                return jsonify({"result": mentor_recommender.recommend_mentors(query, employee_id)}), 200
            else:
                # print("Inside else..")
                result = chain.invoke({"query": query, "property_types": property_types})
                # print(f"Keys: {result.keys()}")
                # return result['intermediate_steps'][1]['context']
                return jsonify({"result": str(result['intermediate_steps'][1]['context'])}), 200

        except Exception as e:
            return jsonify({"error": f"Failed to process query: {str(e)}"}), 500

    @app.route('/cypher_query', methods=['POST'])
    def neo4j_cypher_query():
        """
        Executes a custom Cypher query directly.

        Request JSON:
        - query: The Cypher query to execute.

        Returns:
        - JSON response containing the query results or an error message.
        """
        data = request.json
        query = data.get('query')

        
        if not query:
            return jsonify({"error": "Query not provided"}), 400
        
        try:
            result = db.execute_query(query)
            return jsonify({"result": result}), 200

        except Exception as e:
            return jsonify({"error": f"Failed to execute Cypher query: {str(e)}"}), 500

    @app.route('/update_mentor', methods=['POST'])
    def update_mentor():
        """
        Updates the mentor relationship for an employee.

        Request JSON:
        - employee_id: The ID of the employee.
        - new_mentor_id: The ID of the new mentor.

        Returns:
        - JSON response indicating success or an error message.
        """
        data = request.get_json()

        if 'employee_id' not in data or 'new_mentor_id' not in data:
            return jsonify({'error': 'employee_id and new_mentor_id are required'}), 400

        employee_id = data['employee_id']
        new_mentor_id = data['new_mentor_id']

        try:
            mentor_updater.update_mentor_relationship(employee_id, new_mentor_id)
            return jsonify({'message': 'Mentor relationship updated successfully'}), 200
        except Exception as e:
            return jsonify({'error': f"Failed to update mentor relationship: {str(e)}"}), 500


    @app.route('/update_skills', methods=['POST'])
    def update_skills():
        """API endpoint to extract and update skills."""
        try:
            data = request.json
            folder_path = data.get('folder_path')
            employee_id = data.get('employee_id')
            employee_name = data.get("employee_name") if data.get("employee_name") else None
            # print(f"Input: \nFolder Path: {folder_path}\nEmployee ID: {employee_id}\nEmployee Name: {employee_name}")
            if not folder_path or not employee_id:
                return jsonify({"error": "Invalid input."}), 400

            extracted_skills = skill_extractor.process_folder(folder_path, e_name=employee_name)
            # print(f"Extracted Skills: {extracted_skills}")
            skill_extractor.update_skills_in_neo4j(employee_id, extracted_skills)

            return jsonify({"result": "Skills updated successfully."})
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    

    @app.teardown_appcontext
    def close_connections(exception=None):
        """
        Closes the database connections when the app context ends.
        """
        try:
            db.close()
            # mentor_updater.close()
        except Exception as e:
            app.logger.error(f"Failed to close connections: {str(e)}")
