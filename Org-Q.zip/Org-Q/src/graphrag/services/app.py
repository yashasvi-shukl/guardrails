from flask import Flask
import os
from src.graphrag.config.config import load_config
from src.graphrag.services.api import create_routes

def create_app():
    """Create and configure the Flask app."""
    app = Flask(__name__)
    config_path = os.getenv("ROOT_DIR")+"/src/config/config.yaml"
    if config_path:
        config = load_config(config_path=config_path)
        
        # Create routes dynamically
        create_routes(app, config)
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=8000)
