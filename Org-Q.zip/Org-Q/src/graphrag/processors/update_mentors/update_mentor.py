from neo4j import GraphDatabase, exceptions

class MentorUpdater:
    def __init__(self, driver, config):
        """
        Initialize the Neo4j connection.

        Args:
            uri (str): The URI for the Neo4j database.
            user (str): The username for the Neo4j database.
            password (str): The password for the Neo4j database.

        Raises:
            ValueError: If the URI, username, or password is invalid.
        """
        try:
            self.driver = driver
            self.UPDATE_MENTOR_RELATIONSHIP = config['UPDATE_MENTOR_RELATIONSHIP']
            # Test connection on initialization
            # self._test_connection()
        except exceptions.Neo4jError as e:
            raise ValueError(f"Failed to connect to Neo4j: {str(e)}")

    def close(self):
        """
        Close the Neo4j connection gracefully.

        Raises:
            RuntimeError: If trying to close an already closed connection.
        """
        try:
            if self.driver:
                self.driver.close()
            else:
                raise RuntimeError("Connection already closed.")
        except Exception as e:
            raise RuntimeError(f"Error closing connection: {str(e)}")

    def _test_connection(self):
        """Test the connection to ensure it's valid."""
        with self.driver.session() as session:
            try:
                session.run("RETURN 1")
            except exceptions.Neo4jError as e:
                raise ValueError(f"Failed to test connection: {str(e)}")

    def update_mentor_relationship(self, employee_id, new_mentor_id):
        """
        Update the mentor relationship in the Neo4j database.

        Args:
            employee_id (str): ID of the employee whose mentor is being updated.
            new_mentor_id (str): ID of the new mentor.

        Raises:
            ValueError: If the employee or new mentor does not exist.
            exceptions.Neo4jError: If there is a problem executing the query.
        """
        if not employee_id or not new_mentor_id:
            raise ValueError("Employee ID and new mentor ID cannot be empty.")

        with self.driver.session() as session:
            try:
                # Run the query to update the mentor relationship
                result = session.run(
                    self.UPDATE_MENTOR_RELATIONSHIP,
                    employee_id=employee_id,
                    new_mentor_id=new_mentor_id,
                )
                # Ensure the result contains the updated employee and mentor
                if not result.single():
                    raise ValueError("Employee or new mentor not found.")
            except exceptions.Neo4jError as e:
                raise exceptions.Neo4jError(f"Error executing the query: {str(e)}")
            except Exception as e:
                raise Exception(f"An unexpected error occurred: {str(e)}")
