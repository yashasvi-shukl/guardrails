import os
import logging
from neo4j import GraphDatabase, exceptions as neo4j_exceptions
from flask import Flask, jsonify, request
from langchain.chains import GraphCypherQAChain
from langchain_community.graphs import Neo4jGraph
from langchain_openai import ChatOpenAI
from langchain_core.prompts.prompt import PromptTemplate
from yaml import safe_load

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

class MentorRecommender:
    def __init__(self, driver, graph, llm, config):
        """
        Initialize the MentorRecommender system with configuration details.

        Args:
            config_path (str): Path to the configuration YAML file.

        Raises:
            FileNotFoundError: If the configuration file does not exist.
            ValueError: If the configuration file is invalid or missing required keys.
        """
        # self.config = self._load_config(config_path)
        self.driver = driver
        self.graph = graph
        self.llm = llm
    #     self.emp_query = """MATCH (e:Employee {EmpID: $employee_id})-[:HAS_SKILL]->(s:Skill)
    #     MATCH (e)-[:HAS_CERTIFICATION]->(c:Certification)
    #     MATCH (e)-[:HAS_TITLE]->(t:Title)
    #     RETURN e.EmpID AS EmployeeID,
    #     e.Name AS EmployeeName,
    #     t.Value AS Designation,
    #     collect(DISTINCT s.Name) AS Skills,
    #     collect(DISTINCT c.Name) AS Certifications,
    #     e.Department AS Department,
    #     e.PerformanceScore AS PerformanceScore,
    #     e.CurrentRating AS CurrentRating
    # """
        self.EMP_DETAIL_QUERY = config["EMP_DETAIL_QUERY"]
        # Define mentor recommendation prompt
        self.MENTOR_RECOMMENDER_TEMPLATE = config["MENTOR_RECOMMENDER_TEMPLATE"]

        self.MENTOR_RECOMMENDER_PROMPT = PromptTemplate.from_template(self.MENTOR_RECOMMENDER_TEMPLATE)
        self.recommender_chain = self.MENTOR_RECOMMENDER_PROMPT | self.llm

        self.MENTOR_CYPHER_GENERATION_TEMPLATE = config["MENTOR_CYPHER_GENERATION_TEMPLATE"]
        self.MENTOR_CYPHER_GENERATION_PROMPT = PromptTemplate(input_variables=["schema", "question"], template=self.MENTOR_CYPHER_GENERATION_TEMPLATE)

        
        self.mentor_chain = GraphCypherQAChain.from_llm(
            llm = llm,
            graph=graph,
            top_k = 10,
            verbose=True,
            cypher_prompt=self.MENTOR_CYPHER_GENERATION_PROMPT,
            validate_cypher=True,
            use_function_response=True,
            return_intermediate_steps=True,
            allow_dangerous_requests=True,
        )
        logger.info("MentorRecommender initialized successfully.")

    # @staticmethod
    # def _load_config(config):
    #     """Load configuration from a YAML file."""
    #     try:
    #         with open(config_path, "r") as file:
    #             config = safe_load(file)
    #         required_keys = ["NEO4J_URI", "NEO4J_USER", "NEO4J_PASSWORD", "OPENAI_API_KEY"]
    #         if not all(key in config for key in required_keys):
    #             raise ValueError("Configuration file is missing required keys.")
    #         return config
    #     except FileNotFoundError as e:
    #         logger.error(f"Configuration file not found: {config_path}")
    #         raise
    #     except Exception as e:
    #         logger.error(f"Error loading configuration: {str(e)}")
    #         raise

    def get_employee_details(self, employee_id):
        """
        Fetch employee details from the Neo4j database.

        Args:
            employee_id (str): ID of the employee.

        Returns:
            dict: Employee details.

        Raises:
            ValueError: If the employee ID is invalid or not found.
        """
    
        try:
            with self.driver.session() as session:
                result = session.run(self.EMP_DETAIL_QUERY, employee_id=employee_id)
                print("Query: ", self.EMP_DETAIL_QUERY)
                employee_data = [record.data() for record in result]
                print("Employee Data: ", employee_data)
                if not employee_data:
                    raise ValueError(f"Employee with ID {employee_id} not found.")
                else:
                    return employee_data[0]
        except neo4j_exceptions.Neo4jError as e:
            logger.error(f"Error fetching employee details: {str(e)}")
            raise

    def get_mentors(self, query):
        try:
            result = self.mentor_chain.invoke({"query": query})
            mentor_list = result['intermediate_steps'][1]['context']
            if mentor_list:
                return mentor_list
            else:
                raise ValueError(f"No mentors found.")
        except Exception as e:
            logger.error("Error featching Mentors.")

    def recommend_mentors(self, query, employee_id):
        """
        Recommend mentors based on a query and employee details.

        Args:
            query (str): Mentor query.
            employee_id (str): ID of the employee looking for a mentor.

        Returns:
            str: Recommended mentors or a message if no mentors are found.
        """
        try:
            employee_info = self.get_employee_details(employee_id)
            mentor_list = self.get_mentors(query=query)

            response = self.recommender_chain.invoke(
                {"mentee": employee_info, "query": query, "mentors": mentor_list}
            ).content
            print(f"Recommended mentors: {response}")
            logger.info(f"Recommended mentors: {response}")
            return response
        except Exception as e:
            logger.error(f"Error in mentor recommendation: {str(e)}")
            return "Unable to recommend mentors at this time."

    def close(self):
        """Close the Neo4j connection."""
        try:
            self.graph.driver.close()
            logger.info("Neo4j connection closed.")
        except Exception as e:
            logger.error(f"Error closing Neo4j connection: {str(e)}")


# Example usage:
# recommender = MentorRecommender(config_path="config.yaml")
# response = recommender.recommend_mentors(query="Looking for a Python mentor", employee_id="123")
# print(response)
# recommender.close()
