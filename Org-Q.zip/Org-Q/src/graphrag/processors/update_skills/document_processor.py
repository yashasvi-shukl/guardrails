# Import necessary modules
import yaml
from docx import Document

# Custom exceptions
class ConfigurationError(Exception):
    """Raised when there is an error in configuration."""
    pass

class FileProcessingError(Exception):
    """Raised when there is an error in file processing."""
    pass

class Neo4jQueryError(Exception):
    """Raised when there is an error executing a Neo4j query."""
    pass

# Utility class for configuration
class ConfigLoader:
    @staticmethod
    def load_config(file_path):
        """Load configuration from a YAML file."""
        try:
            with open(file_path, 'r') as file:
                return yaml.safe_load(file)
        except Exception as e:
            raise ConfigurationError(f"Error loading config file: {e}")

# Utility class for file operations
class FileProcessor:
    @staticmethod
    def extract_text_from_docx(file_path):
        """Extract text from a .docx file."""
        try:
            doc = Document(file_path)
            text = [paragraph.text.strip() for paragraph in doc.paragraphs if paragraph.text.strip()]
            return "\n".join(text)
        except Exception as e:
            raise FileProcessingError(f"Error processing DOCX file: {e}")

    @staticmethod
    def load_text_file(file_path):
        """Load and read a text file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return file.read()
        except Exception as e:
            raise FileProcessingError(f"Error loading text file: {e}")