# Neo4j interaction class
from src.graphrag.processors.update_skills.document_processor import Neo4jQueryError

class Neo4jHandler:
    def __init__(self, driver):
        self.driver = driver

    def execute_query(self, query, employee_id):
        """Execute a Cypher query on the Neo4j database to get the skills."""
        try:
            with self.driver.session() as session:
                result = session.run(query, employee_id=employee_id)
                return [record.data() for record in result]
        except Exception as e:
            raise Neo4jQueryError(f"Error executing query: {e}")

    def close(self):
        self.driver.close()