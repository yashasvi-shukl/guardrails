# Import necessary modules
import os
import yaml
import ast
from flask import Flask, jsonify, request
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from docx import Document
from langchain.chains import GraphCypherQAChain
from langchain_community.graphs import Neo4jGraph
from neo4j import GraphDatabase
from src.graphrag.processors.update_skills.document_processor import ConfigurationError, FileProcessingError, Neo4jQueryError, FileProcessor
from src.graphrag.processors.update_skills.utils import Neo4jHandler


# Main application class
class SkillExtractorApp:
    def __init__(self, config, llm, graph, driver):
        # self.config = config #ConfigLoader.load_config(config_path)
        self.llm = llm
        self.prompt_template = PromptTemplate(
            input_variables=["context", "question"],
            template = config["GET_SKILLS"]
        )
        self.chain = self.prompt_template | self.llm

        self.graph = graph
        self.graph.refresh_schema()
        self.driver = driver
        self.neo4j_handler = Neo4jHandler(driver=self.driver)
        self.UPDATE_SKILLS = config["UPDATE_SKILLS"]

    def query_skills(self, context, e_name=None, is_document=True):
        """Query skills using LLM based on context."""
        question = "List all the skills of the employee present in the context." if is_document else f"List all the skills of {e_name} learned or gained based on above chat history."
        response = self.chain.invoke({'question': question, 'context': context})
        return ast.literal_eval(response.content)

    def process_folder(self, folder_path, e_name=None):
        """Process files in a folder to extract skills."""
        extracted_skills = []
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if filename.endswith('.docx'):
                context = FileProcessor.extract_text_from_docx(file_path)
                skills = self.query_skills(context, is_document=True)
                extracted_skills.extend(skills)
            elif filename.endswith('.txt'):
                context = FileProcessor.load_text_file(file_path)
                skills = self.query_skills(context, e_name=e_name, is_document=False)
                extracted_skills.extend(skills)
        return extracted_skills

    def update_skills_in_neo4j(self, employee_id, skills):
        """Update skills for an employee in Neo4j."""
        query = """MATCH (e:Employee {EmpID: $employee_id})-[:HAS_SKILL]->(s:Skill) RETURN s.Name"""
        existing_skills = []
        try:
            existing_skills = self.neo4j_handler.execute_query(query, employee_id)
            # print(f"Existing Skills: {existing_skills}")
            existing_skills = ast.literal_eval(self.llm.invoke(f"""Your task is to return the following neo4j output in the form of list of values containing skills nothing else: 
                                                               
                                                                Neo4j response: \n{existing_skills}""" +"""
                                                                
                                                                Example:
                                                                    Neo4j response: [{'s.Name': 'Python'}, {'s.Name': 'Risk Assessment and Mitigation'}, {'s.Name': 'Leadership'}, {'s.Name': 'Team Building'}]
                                                                    Final response: ['Python', 'Risk Assessment and Mitigation', 'Leadership', 'Team Building']
                                                                    
                                                                [Your final response goes here]
                                                                """).content)
            # print(f"Existing Skills: {existing_skills}")
        except Exception as e:
            raise Neo4jQueryError("Query failed....")
        combined_skills = list(set(existing_skills + skills))
        # print(f"Combined Skills: {combined_skills}")

        with self.driver.session() as session:
            session.run(
                self.UPDATE_SKILLS,
                employee_id = employee_id,
                skills = ['Project Management', 'Risk Assessment and Mitigation', 'Leadership and Team Building'] #combined_skills
            )
