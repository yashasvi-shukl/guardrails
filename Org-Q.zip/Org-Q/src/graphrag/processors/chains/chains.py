import logging
from langchain.prompts import PromptTemplate
from langchain.chains import GraphCypherQAChain
from langchain_openai import ChatOpenAI
from langchain_community.graphs import Neo4jGraph

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

class CypherChainBuilder:
    def __init__(self, llm, graph, config):
        """
        Initialize the CypherChainBuilder with configuration details.

        Args:
            config (dict): Configuration containing Neo4j and OpenAI details.

        Raises:
            ValueError: If the configuration is missing required keys.
        """
        # self.config = self._validate_config(config)
        # self.graph = self._initialize_graph()
        # self.llm = self._initialize_llm()
        self.graph = graph
        self.llm = llm
        # Define the Cypher generation template
        self.CYPHER_GENERATION_TEMPLATE = config["CYPHER_GENERATION_TEMPLATE"]
        self.cypher_prompt = PromptTemplate(input_variables=["schema", "question"], template=self.CYPHER_GENERATION_TEMPLATE)
        logger.info("CypherChainBuilder initialized successfully.")

    @staticmethod
    def _validate_config(config):
        """Validate the configuration dictionary."""
        required_keys = ["NEO4J_URI", "NEO4J_USER", "NEO4J_PASSWORD", "OPENAI_API_KEY"]
        if not all(key in config for key in required_keys):
            logger.error("Configuration is missing required keys.")
            raise ValueError("Configuration is missing required keys.")
        return config

    def _initialize_graph(self):
        """Initialize and return the Neo4j graph."""
        try:
            graph = Neo4jGraph(
                url=self.config["NEO4J_URI"],
                username=self.config["NEO4J_USER"],
                password=self.config["NEO4J_PASSWORD"],
            )
            graph.refresh_schema()
            logger.info("Neo4j graph initialized and schema refreshed.")
            return graph
        except Exception as e:
            logger.error(f"Error initializing Neo4j graph: {str(e)}")
            raise

    def _initialize_llm(self):
        """Initialize and return the ChatOpenAI instance."""
        try:
            llm = ChatOpenAI(api_key=self.config["OPENAI_API_KEY"])
            logger.info("ChatOpenAI instance initialized.")
            return llm
        except Exception as e:
            logger.error(f"Error initializing ChatOpenAI: {str(e)}")
            raise

    def create_cypher_chain(self):
        """
        Create and return the Cypher query generation chain.

        Returns:
            GraphCypherQAChain: The configured chain for generating Cypher queries.

        Raises:
            Exception: If the chain creation fails.
        """
        try:
            

            # Create the Cypher query chain
            chain = GraphCypherQAChain.from_llm(
                llm=self.llm,
                graph=self.graph,
                top_k=20,
                verbose=True,
                cypher_prompt=self.cypher_prompt,
                validate_cypher=True,
                use_function_response=False,
                return_intermediate_steps = True
            )
            logger.info("Cypher query generation chain created successfully.")
            return chain
        except Exception as e:
            logger.error(f"Error creating Cypher query chain: {str(e)}")
            raise

    def close(self):
        """Close the Neo4j graph connection."""
        try:
            self.graph.close()
            logger.info("Neo4j graph connection closed.")
        except Exception as e:
            logger.error(f"Error closing Neo4j connection: {str(e)}")


# Example usage:
# config = {
#     "NEO4J_URI": "neo4j://localhost:7687",
#     "NEO4J_USER": "neo4j",
#     "NEO4J_PASSWORD": "password",
#     "OPENAI_API_KEY": "your-openai-api-key"
# }
# cypher_builder = CypherChainBuilder(config)
# chain = cypher_builder.create_cypher_chain()
# cypher_builder.close()
