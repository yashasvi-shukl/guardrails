from neo4j import GraphDatabase
from langchain_community.graphs import Neo4jGraph

class Neo4jConnection:
    def __init__(self, uri, user, password):
        self.uri = uri
        self.user = user
        self.password = password
        self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
        self.graph = Neo4jGraph(url = self.uri,
                                username = self.user,
                                password = self.password)
        
    def execute_query(self, query):
        """Execute a Cypher query in the Neo4j database."""
        with self.driver.session() as session:
            result = session.run(query)
            return [record.data() for record in result]

    def close(self):
        """Close the Neo4j database connection."""
        if self.driver:
            self.driver.close()


    def fetch_schema_properties(self, config):
        query = config.get("GET_PROPERTIES")
        
        result = self.execute_query(query)
        
        return result

    def convert_to_markdown_table(self, data):
        if not data:
            return "No data found."
        
        header = "| Node Type | Property Name | Property Types |\n|---|---|---|"
        rows = [f"| {row['nodeType']} | {row['propertyName']} | {row['propertyTypes']} |" for row in data]
    
        return f"{header}\n" + "\n".join(rows)