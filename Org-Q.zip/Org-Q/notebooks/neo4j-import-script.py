from neo4j import GraphDatabase
import json
import datetime

class Neo4jEmployeeImporter:
    def __init__(self, uri, username, password):
        self.driver = GraphDatabase.driver(uri, auth=(username, password))

    def close(self):
        self.driver.close()

    def import_data(self, data):
        with self.driver.session() as session:
            # Clear existing data (optional)
            session.run("MATCH (n) DETACH DELETE n")
            
            # Import employees and related data
            for employee in data["employees"]:
                self._create_employee(session, employee)
    
    def _create_employee(self, session, employee):
        # Create employee node
        emp_query = """
        CREATE (e:Employee {
            emp_id: $emp_id,
            career_level: $career_level,
            engagement_score: $engagement_score,
            last_promotion_date: $last_promotion_date
        })
        RETURN e
        """
        
        # Parse date to Neo4j compatible format
        promotion_date = None
        if employee.get("last_promotion_date"):
            try:
                promotion_date = employee["last_promotion_date"]
            except ValueError:
                promotion_date = None
                
        employee_result = session.run(
            emp_query,
            emp_id=employee["emp_id"],
            career_level=employee["career_level"],
            engagement_score=employee["engagement_score"],
            last_promotion_date=promotion_date
        )
        
        # Create and connect career interests
        for interest in employee.get("career_interests", []):
            self._create_career_interest(session, employee["emp_id"], interest)
        
        # Create and connect skills
        for skill in employee.get("skills", []):
            self._create_skill(session, employee["emp_id"], skill)
        
        # Create and connect completed courses
        for course_id in employee.get("completed_courses", []):
            self._create_course_relationship(session, employee["emp_id"], course_id, "COMPLETED")
        
        # Create and connect enrolled courses
        for course_id in employee.get("enrolled_courses", []):
            self._create_course_relationship(session, employee["emp_id"], course_id, "ENROLLED_IN")
        
        # Create and connect completed programs
        for program_id in employee.get("completed_programs", []):
            self._create_program_relationship(session, employee["emp_id"], program_id)
        
        # Create and connect career feedback
        for feedback in employee.get("career_feedback", []):
            self._create_feedback(session, employee["emp_id"], feedback)
        
        # Create and connect blockers
        for blocker_id in employee.get("blockers", []):
            self._create_blocker_relationship(session, employee["emp_id"], blocker_id)
        
        # Create and connect eligible roles
        for role_id in employee.get("eligible_roles", []):
            self._create_role_relationship(session, employee["emp_id"], role_id)
        
        # Create and connect career path
        if employee.get("career_path"):
            self._create_career_path_relationship(session, employee["emp_id"], employee["career_path"])
        
        # Create and connect eligible policies
        for policy_id in employee.get("eligible_policies", []):
            self._create_policy_relationship(session, employee["emp_id"], policy_id)
    
    def _create_career_interest(self, session, emp_id, interest):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (i:Interest {name: $interest})
        CREATE (e)-[:INTERESTED_IN]->(i)
        """
        session.run(query, emp_id=emp_id, interest=interest)
    
    def _create_skill(self, session, emp_id, skill):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (s:Skill {name: $name, category: $category})
        CREATE (e)-[:HAS_SKILL {
            proficiency_level: $proficiency_level,
            last_assessed: $last_assessed
        }]->(s)
        """
        
        last_assessed = None
        if skill.get("last_assessed"):
            try:
                last_assessed = skill["last_assessed"]
            except ValueError:
                last_assessed = None
                
        session.run(
            query, 
            emp_id=emp_id,
            name=skill["name"],
            category=skill["category"],
            proficiency_level=skill["proficiency_level"],
            last_assessed=last_assessed
        )
    
    def _create_course_relationship(self, session, emp_id, course_id, rel_type):
        query = f"""
        MATCH (e:Employee {{emp_id: $emp_id}})
        MERGE (c:Course {{course_id: $course_id}})
        CREATE (e)-[:{rel_type}]->(c)
        """
        session.run(query, emp_id=emp_id, course_id=course_id)
    
    def _create_program_relationship(self, session, emp_id, program_id):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (p:Program {program_id: $program_id})
        CREATE (e)-[:COMPLETED_PROGRAM]->(p)
        """
        session.run(query, emp_id=emp_id, program_id=program_id)
    
    def _create_feedback(self, session, emp_id, feedback):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        CREATE (f:Feedback {
            feedback_id: $feedback_id,
            source: $source,
            date: $date,
            topic: $topic,
            sentiment: $sentiment
        })
        CREATE (e)-[:RECEIVED_FEEDBACK]->(f)
        """
        
        feedback_date = None
        if feedback.get("date"):
            try:
                feedback_date = feedback["date"]
            except ValueError:
                feedback_date = None
                
        session.run(
            query,
            emp_id=emp_id,
            feedback_id=feedback["feedback_id"],
            source=feedback["source"],
            date=feedback_date,
            topic=feedback["topic"],
            sentiment=feedback["sentiment"]
        )
    
    def _create_blocker_relationship(self, session, emp_id, blocker_id):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (b:Blocker {blocker_id: $blocker_id})
        CREATE (e)-[:HAS_BLOCKER]->(b)
        """
        session.run(query, emp_id=emp_id, blocker_id=blocker_id)
    
    def _create_role_relationship(self, session, emp_id, role_id):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (r:Role {role_id: $role_id})
        CREATE (e)-[:ELIGIBLE_FOR]->(r)
        """
        session.run(query, emp_id=emp_id, role_id=role_id)
    
    def _create_career_path_relationship(self, session, emp_id, path_id):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (p:CareerPath {path_id: $path_id})
        CREATE (e)-[:FOLLOWS_PATH]->(p)
        """
        session.run(query, emp_id=emp_id, path_id=path_id)
    
    def _create_policy_relationship(self, session, emp_id, policy_id):
        query = """
        MATCH (e:Employee {emp_id: $emp_id})
        MERGE (p:Policy {policy_id: $policy_id})
        CREATE (e)-[:ELIGIBLE_FOR_POLICY]->(p)
        """
        session.run(query, emp_id=emp_id, policy_id=policy_id)


# Main function to run the import
def main():
    # Connection parameters - replace with your Neo4j credentials
    uri = "neo4j+s://69b7358a.databases.neo4j.io"
    username = "neo4j"
    password = "eqwnrv9rYVbl6vZt2hsp8C_NVOk-s4BdcoDEBltPQKo"
    
    # Load the JSON data from file
    try:
        with open('employee_career_data.json', 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        print("Error: employee_data.json file not found")
        return
    
    # Initialize importer and import data
    importer = Neo4jEmployeeImporter(uri, username, password)
    try:
        importer.import_data(data)
        print("Successfully imported employee data into Neo4j")
    except Exception as e:
        print(f"Error importing data: {e}")
    finally:
        importer.close()


if __name__ == "__main__":
    main()
