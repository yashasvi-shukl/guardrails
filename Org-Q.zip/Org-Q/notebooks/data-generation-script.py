import random
import json
from datetime import datetime, timedelta
import uuid

# Set random seed for reproducibility
random.seed(42)

# Helper functions
def generate_date(start_year=2020, end_year=2025):
    year = random.randint(start_year, end_year)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return f"{year}-{month:02d}-{day:02d}"

def generate_uuid():
    return str(uuid.uuid4())

# Lists for random selection
departments = ["Engineering", "Finance", "Marketing", "Sales", "HR", "Operations", "Customer Support", "Product", "Legal", "Research"]
technical_skills = ["Python", "Java", "JavaScript", "SQL", "Data Analysis", "Machine Learning", "Cloud Computing", "DevOps", "React", "Node.js"]
soft_skills = ["Leadership", "Communication", "Problem Solving", "Teamwork", "Time Management", "Critical Thinking", "Adaptability", "Creativity", "Negotiation", "Conflict Resolution"]
course_providers = ["Coursera", "Udemy", "LinkedIn Learning", "Pluralsight", "edX", "Internal Training", "O'Reilly", "Skillsoft", "Udacity", "Harvard Business Review"]
career_levels = ["Junior", "Mid-level", "Senior", "Lead", "Manager", "Director", "VP", "C-Suite"]
titles = ["Software Engineer", "Data Scientist", "Product Manager", "Financial Analyst", "HR Specialist", "Sales Representative", "Marketing Specialist", "Operations Manager", "Legal Counsel", "Research Scientist"]

# Generate organization-level data

# Learning Programs
learning_programs = []
program_types = ["Leadership Development", "Technical Training", "Soft Skills", "Industry Certification", "Compliance Training"]
quarters = ["Q1 2025", "Q2 2025", "Q3 2025", "Q4 2025"]

for i in range(20):
    program_type = random.choice(program_types)
    program_id = f"PROG-{generate_uuid()[:8]}"
    
    # Ensure unique program names
    program_name = f"{program_type} - Level {random.randint(1, 3)} - {random.choice(['Basic', 'Advanced', 'Mastery', 'Specialized'])}"
    
    quarter = random.choice(quarters)
    if quarter == "Q1 2025":
        start_date = f"2025-{random.randint(1, 3)}-{random.randint(1, 28)}"
        end_date = f"2025-{random.randint(3, 4)}-{random.randint(1, 28)}"
    elif quarter == "Q2 2025":
        start_date = f"2025-{random.randint(4, 6)}-{random.randint(1, 28)}"
        end_date = f"2025-{random.randint(6, 7)}-{random.randint(1, 28)}"
    elif quarter == "Q3 2025":
        start_date = f"2025-{random.randint(7, 9)}-{random.randint(1, 28)}"
        end_date = f"2025-{random.randint(9, 10)}-{random.randint(1, 28)}"
    else:
        start_date = f"2025-{random.randint(10, 12)}-{random.randint(1, 28)}"
        end_date = f"2026-{random.randint(1, 2)}-{random.randint(1, 28)}"
    
    learning_programs.append({
        "program_id": program_id,
        "name": program_name,
        "type": program_type,
        "start_date": start_date,
        "end_date": end_date,
        "seats_available": random.randint(10, 50),
        "quarter": quarter
    })

# Courses
courses = []
skill_categories = ["Technical", "Leadership", "Communication", "Domain Knowledge", "Compliance"]
for i in range(50):
    course_id = f"COURSE-{generate_uuid()[:8]}"
    skill_category = random.choice(skill_categories)
    
    courses.append({
        "course_id": course_id,
        "name": f"{random.choice(['Introduction to', 'Advanced', 'Mastering', 'Fundamentals of', 'Practical'])} {random.choice(technical_skills + soft_skills)}",
        "provider": random.choice(course_providers),
        "skill_category": skill_category,
        "description": f"This course provides {skill_category.lower()} training for professionals.",
        "duration": random.randint(1, 12) * 5,  # in hours
        "cost": round(random.uniform(0, 2000), 2),
        "reimbursement_eligible": random.choice([True, False])
    })

# Engagement Surveys
engagement_surveys = []
for dept in departments:
    for quarter in quarters:
        survey_id = f"SURVEY-{dept[:3]}-{quarter.replace(' ', '')}"
        
        engagement_surveys.append({
            "survey_id": survey_id,
            "date": generate_date(2024, 2025),
            "department": dept,
            "participation_rate": round(random.uniform(0.5, 0.95), 2),
            "overall_score": round(random.uniform(3.0, 4.8), 1)
        })

# Roles (some open, some filled)
roles = []
for i in range(100):
    role_id = f"ROLE-{generate_uuid()[:8]}"
    department = random.choice(departments)
    level = random.choice(career_levels)
    title = random.choice(titles)
    
    # For titles like "Software Engineer", add the level
    if any(word in title for word in ["Engineer", "Analyst", "Specialist", "Representative", "Scientist"]):
        title = f"{level} {title}"
    
    roles.append({
        "role_id": role_id,
        "title": title,
        "department": department,
        "level": level,
        "is_open": random.choice([True, False]),
        "posting_date": generate_date(2024, 2025) if random.random() > 0.7 else None,
        "required_skills": random.sample(technical_skills + soft_skills, random.randint(3, 7))
    })

# Career Paths
career_paths = []
for department in departments:
    for level_idx, level in enumerate(career_levels[:-1]):  # exclude the highest level
        path_id = f"PATH-{department[:3]}-{level[:3]}"
        next_level = career_levels[level_idx + 1]
        
        career_paths.append({
            "path_id": path_id,
            "path_name": f"{department} {level} to {next_level} Path",
            "level": level,
            "description": f"Career progression path from {level} to {next_level} in the {department} department"
        })

# Compensation Policies
compensation_policies = []
policy_types = ["Bonus", "Reimbursement", "Salary Increase", "Stock Options", "Performance Incentive"]
for policy_type in policy_types:
    for level in career_levels:
        policy_id = f"POLICY-{policy_type[:3]}-{level[:3]}"
        
        amount = None
        if policy_type == "Bonus":
            amount = round(random.uniform(0.05, 0.30), 2)  # as percentage of salary
        elif policy_type == "Reimbursement":
            amount = round(random.uniform(1000, 10000), 2)  # fixed amount
        elif policy_type == "Salary Increase":
            amount = round(random.uniform(0.02, 0.15), 2)  # as percentage
        elif policy_type == "Stock Options":
            amount = random.randint(100, 10000)  # number of options
        elif policy_type == "Performance Incentive":
            amount = round(random.uniform(0.01, 0.10), 2)  # as percentage
        
        compensation_policies.append({
            "policy_id": policy_id,
            "type": policy_type,
            "eligibility_criteria": f"Must be at {level} level with performance rating above 3",
            "amount": amount,
            "level_requirement": level
        })

# Career Blockers (common issues)
career_blockers = [
    {
        "blocker_id": "BLOCKER-001",
        "description": "Missing technical certification",
        "suggested_remedy": "Complete relevant certification courses"
    },
    {
        "blocker_id": "BLOCKER-002",
        "description": "Insufficient leadership experience",
        "suggested_remedy": "Take on team lead roles in projects"
    },
    {
        "blocker_id": "BLOCKER-003",
        "description": "Communication skills need improvement",
        "suggested_remedy": "Enroll in communication workshops"
    },
    {
        "blocker_id": "BLOCKER-004",
        "description": "Performance below expectations",
        "suggested_remedy": "Create performance improvement plan with manager"
    },
    {
        "blocker_id": "BLOCKER-005",
        "description": "Lacking cross-functional experience",
        "suggested_remedy": "Participate in projects across different departments"
    }
]

# Now generate employee-specific data
employees_data = []

for emp_id in range(1, 201):
    department = random.choice(departments)
    career_level = random.choice(career_levels)
    
    # Employee base data
    employee = {
        "emp_id": emp_id,
        "career_level": career_level,
        "engagement_score": round(random.uniform(2.0, 5.0), 1),
        "last_promotion_date": generate_date(2020, 2024) if random.random() > 0.3 else None,
        "career_interests": random.sample(departments, random.randint(1, 3))
    }
    
    # Employee Skills (5-10 skills per employee)
    skills = []
    for _ in range(random.randint(5, 10)):
        skill_name = random.choice(technical_skills + soft_skills)
        skills.append({
            "name": skill_name,
            "proficiency_level": random.randint(1, 5),
            "category": "Technical" if skill_name in technical_skills else "Soft",
            "last_assessed": generate_date(2023, 2024)
        })
    
    # Skill Assessments (0-3 per employee)
    skill_assessments = []
    for _ in range(random.randint(0, 3)):
        assessment_id = f"ASSESSMENT-{emp_id}-{generate_uuid()[:6]}"
        skill_assessments.append({
            "assessment_id": assessment_id,
            "date": generate_date(2023, 2024),
            "assessor": f"Manager-{random.randint(1, 50)}",
            "overall_score": random.randint(1, 5)
        })
    
    # Completed Courses (0-5 per employee)
    completed_courses = random.sample(courses, random.randint(0, 5))
    
    # Enrolled Courses (0-2 per employee)
    enrolled_courses = random.sample([c for c in courses if c not in completed_courses], random.randint(0, 2))
    
    # Completed Learning Programs (0-3 per employee)
    completed_programs = random.sample(learning_programs, random.randint(0, 3))
    
    # Career Feedback (0-3 per employee)
    career_feedback = []
    for _ in range(random.randint(0, 3)):
        feedback_id = f"FEEDBACK-{emp_id}-{generate_uuid()[:6]}"
        career_feedback.append({
            "feedback_id": feedback_id,
            "source": random.choice(["Manager", "Peer", "Self"]),
            "date": generate_date(2023, 2024),
            "topic": random.choice(["Communication", "Technical Skills", "Leadership", "Team Collaboration"]),
            "sentiment": random.choice(["Positive", "Negative", "Neutral", "Mixed"])
        })
    
    # Promotions (0-2 per employee)
    promotions = []
    if career_level != "Junior" and random.random() > 0.5:
        idx = career_levels.index(career_level)
        previous_levels = career_levels[:idx]
        
        for _ in range(random.randint(1, min(2, len(previous_levels)))):
            promotion_id = f"PROMOTION-{emp_id}-{generate_uuid()[:6]}"
            old_level = random.choice(previous_levels)
            new_level = career_levels[career_levels.index(old_level) + 1]
            
            promotions.append({
                "promotion_id": promotion_id,
                "date": generate_date(2020, 2024),
                "old_role": f"{old_level} {random.choice(titles)}",
                "new_role": f"{new_level} {random.choice(titles)}",
                "department": department
            })
    
    # Career Blockers (0-2 per employee)
    employee_blockers = random.sample(career_blockers, random.randint(0, 2))
    
    # Eligible Roles (0-3 per employee)
    eligible_roles = []
    for _ in range(random.randint(0, 3)):
        role = random.choice([r for r in roles if r["is_open"] and r["level"] in career_levels[career_levels.index(career_level):career_levels.index(career_level)+2]])
        eligible_roles.append(role["role_id"])
    
    # Career Path (if not at highest level)
    employee_career_path = None
    if career_level != career_levels[-1]:
        matching_paths = [p for p in career_paths if p["level"] == career_level and p["path_name"].startswith(department)]
        if matching_paths:
            employee_career_path = matching_paths[0]["path_id"]
    
    # Eligible Compensation Policies
    eligible_policies = [p["policy_id"] for p in compensation_policies if p["level_requirement"] == career_level]
    
    # Add all related data to employee
    employee.update({
        "skills": skills,
        "skill_assessments": skill_assessments,
        "completed_courses": [c["course_id"] for c in completed_courses],
        "enrolled_courses": [c["course_id"] for c in enrolled_courses],
        "completed_programs": [p["program_id"] for p in completed_programs],
        "career_feedback": career_feedback,
        "promotions": promotions,
        "blockers": [b["blocker_id"] for b in employee_blockers],
        "eligible_roles": eligible_roles,
        "career_path": employee_career_path,
        "eligible_policies": eligible_policies
    })
    
    employees_data.append(employee)

# Save all the generated data to files for reference
data = {
    "employees": employees_data,
    "learning_programs": learning_programs,
    "courses": courses,
    "engagement_surveys": engagement_surveys,
    "roles": roles,
    "career_paths": career_paths,
    "compensation_policies": compensation_policies,
    "career_blockers": career_blockers
}

# Uncomment to save to file
with open('employee_career_data.json', 'w') as f:
    json.dump(data, f, indent=2)

# Print data for employee with ID 200
print("Data for Employee ID 200:")
emp_200 = employees_data[199]  # index 199 corresponds to ID 200
print(json.dumps(emp_200, indent=2))

# For demo purpose, print counts of generated data
print(f"\nGenerated data counts:")
print(f"Employees: {len(employees_data)}")
print(f"Learning Programs: {len(learning_programs)}")
print(f"Courses: {len(courses)}")
print(f"Engagement Surveys: {len(engagement_surveys)}")
print(f"Roles: {len(roles)}")
print(f"Career Paths: {len(career_paths)}")
print(f"Compensation Policies: {len(compensation_policies)}")
print(f"Career Blockers: {len(career_blockers)}")
