import ast

def query_llm_with_doc(chain, context, e_name=None, indicator=True):
    """
    Query the LLM with a provided context (document or chat) to extract skills.
    
    Args:
        chain: The chain combining the prompt template and LLM.
        context (str): The context (text from document or chat).
        e_name (str, optional): The employee name, used in chat-based queries.
        indicator (bool): Determines if document-based query or chat-based query should be used.
    
    Returns:
        list: List of extracted skills.
    """
    if indicator:
        doc_question = "List all the skills of employee."
        response = chain.invoke({'question': doc_question, 'context': context})
        return ast.literal_eval(response.content)
    else:
        chat_question = f"List all the skills of {e_name} learned or gained based on the above chat conversation. List only skill and service names."
        response = chain.invoke({'question': chat_question, 'context': context})
        return ast.literal_eval(response.content)

