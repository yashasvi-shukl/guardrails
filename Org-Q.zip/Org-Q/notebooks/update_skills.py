import os
import yaml
import ast
from flask import Flask, jsonify, request
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from docx import Document
from langchain.chains import GraphCypherQAChain
from langchain_community.graphs import Neo4jGraph
from neo4j import GraphDatabase

app = Flask(__name__)

# Load configuration from a YAML file
with open('config.yaml', 'r') as file:
    config = yaml.safe_load(file)

# Set OpenAI API key from the loaded configuration
os.environ['OPENAI_API_KEY'] = config['OPENAI_API_KEY']

# Initialize LLM and prompt templates
llm = ChatOpenAI(model_name="gpt-4o-mini")

# Define the prompt template for querying skills
prompt_template = PromptTemplate(
    input_variables=["context", "question"],
    template="""Use the provided context to answer the question.\n\nContext:\n{context}\n\nQuestion: {question}.\n\n Your final response should only be a list of values.
    Your answer: [List of string]"""
)

# Combine prompt template with LLM
chain = prompt_template | llm

# Initialize the Neo4j graph and refresh schema
graph = Neo4jGraph(url=config['NEO4J_URI'], username=config['NEO4J_USER'], password=config['NEO4J_PASSWORD'])
graph.refresh_schema()

# Cypher generation template for querying the Neo4j graph
CYPHER_GENERATION_TEMPLATE = """Task: Generate Cypher statement to query a neo4j graph database.

Instructions:
Use only the provided relationship types and properties in the schema.
Do not use any other relationship types or properties that are not provided.
Schema:
{schema}
Note: Do not include any explanations or apologies in your responses.
Do not respond to any questions that might ask anything else than for you to construct a Cypher statement.
Do not include any text except the generated Cypher statement.

As skills and certification comprises of list of values, always use the CONTAINS operator for entities and ensure the query is case insensitive.
Examples: Here are a few examples of generated Cypher statements for particular questions:

    # Names of employees skilled in Python Programming?
    MATCH (e:Employee)-[:HAS_SKILL]->(s:Skill)
    WHERE toLower(s.Name) CONTAINS toLower('Python')
    RETURN e.Name

The question is:
{question}"""

# Initialize the prompt template for Cypher query generation
CYPHER_GENERATION_PROMPT = PromptTemplate(
    input_variables=["schema", "question"], template=CYPHER_GENERATION_TEMPLATE
)

# Initialize the GraphCypherQAChain
graph_chain = GraphCypherQAChain.from_llm(
    llm=llm,
    graph=graph,
    top_k=10,
    verbose=True,
    cypher_prompt=CYPHER_GENERATION_PROMPT,
    validate_cypher=True,
    use_function_response=True,
)

# Initialize Neo4j driver
driver = GraphDatabase.driver(config['NEO4J_URI'], auth=(config['NEO4J_USER'], config['NEO4J_PASSWORD']))

# Function to extract text from a Word document
def extract_text_from_docx(file_path):
    """
    Extract text from a .docx file and return it as a string.
    
    Args:
        file_path (str): The path to the Word document.
    
    Returns:
        str: The extracted text from the document.
    """
    doc = Document(file_path)
    text = [paragraph.text.strip() for paragraph in doc.paragraphs if paragraph.text.strip()]
    return "\n".join(text)

# Function to load and read a text file
def load_text_file(file_path):
    """
    Load and read the contents of a text file.
    
    Args:
        file_path (str): The path to the text file.
    
    Returns:
        str: The content of the text file.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except Exception as e:
        return str(e)

# Function to query the LLM with document or chat context
def query_llm_with_doc(chain, context, e_name=None, indicator=True):
    """
    Query the LLM with a provided context (document or chat) to extract skills.
    
    Args:
        chain: The chain combining the prompt template and LLM.
        context (str): The context (text from document or chat).
        e_name (str, optional): The employee name, used in chat-based queries.
        indicator (bool): Determines if document-based query or chat-based query should be used.
    
    Returns:
        list: List of extracted skills.
    """
    if indicator:
        doc_question = "List all the skills of employee."
        response = chain.invoke({'question': doc_question, 'context': context})
        return ast.literal_eval(response.content)
    else:
        chat_question = f"List all the skills of {e_name} learned or gained based on the above chat conversation. List only skill and service names."
        response = chain.invoke({'question': chat_question, 'context': context})
        return ast.literal_eval(response.content)

# Function to get the manager's employee ID from a PRD document
def get_manager(llm, prd_doc):
    """
    Extract the employee ID of the supervisor from a PRD document.
    
    Args:
        llm: The LLM instance used for querying.
        prd_doc (str): The PRD document content.
    
    Returns:
        str: The employee ID of the supervisor.
    """
    prompt = PromptTemplate(input_variables=['question', 'context'], 
                            template="Your task is to only return the employee id of the Supervisor from the following PRD document: \n\nPRD Document: \n{prd_doc}\n\n\nYour response should be a employee id only. For example: 1")
    chain = prompt | llm
    response = chain.invoke(prd_doc).content
    return response

# Function to run Cypher queries against Neo4j
def neo4j_cypher_query(query):
    """
    Execute a Cypher query on the Neo4j database.
    
    Args:
        query (str): The Cypher query to be executed.
    
    Returns:
        dict: A dictionary with either the query result or an error message.
    """
    if not query:
        return {"error": "Query not provided"}

    try:
        with driver.session() as session:
            result = session.run(query)
            result_list = [record.data() for record in result]
        return {"result": result_list}
    except Exception as e:
        return {"error": str(e)}

# Function to process all files in a folder
def process_files_in_folder(folder_path, ename=None):
    """
    Process all files in a folder, extracting skills from Word and text files.
    
    Args:
        folder_path (str): Path to the folder containing files.
        ename (str, optional): The employee name for chat-based queries.
    
    Returns:
        tuple: A tuple containing the extracted skills and the new manager ID.
    """
    extracted_skills = []
    new_manager_id = None
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)

        # Process Word documents
        if filename.endswith('.docx'):
            if 'prd_' in filename:
                prd_doc = extract_text_from_docx(file_path)
                new_manager_id = get_manager(llm=llm, prd_doc=prd_doc)
            else:
                context = extract_text_from_docx(file_path)
                skills = query_llm_with_doc(chain, context)
                extracted_skills.extend(skills)
        
        # Process text files
        elif filename.endswith('.txt'):
            context = load_text_file(file_path)
            skills = query_llm_with_doc(chain, context, e_name=ename, indicator=False)
            extracted_skills.extend(skills)
    
    return extracted_skills, new_manager_id

@app.route('/get_skills', methods=['POST'])
def get_skills():
    """
    Flask route to extract and update skills for an employee.
    
    Expects a JSON body with folder path, employee ID, and employee name.
    Queries skills from documents and updates them in the Neo4j database.
    
    Returns:
        JSON response with the result of the update operation.
    """
    data = request.json
    folder_path = data.get('folder_path')
    employee_id = data.get("employee_id")
    ename = data.get('ename')

    if not folder_path:
        return jsonify({"error": "Folder path not provided"}), 400

    try:
        # Extract and query skills from all files in the folder
        graph.refresh_schema()
        new_skills, new_manager_id = process_files_in_folder(folder_path, ename)

        # Query existing skills from Neo4j
        query = f"""MATCH (e:Employee)-[:HAS_SKILL]->(s:Skill)
                            WHERE e.EmpID = {employee_id}
                            RETURN s.Name"""
        
        old_skill = ast.literal_eval(llm.invoke(f"Your task is to return the following neo4j output in the form of list of values nothing else: {neo4j_cypher_query(query)}").content)
        old_skill.extend(new_skills)
        updated_skills = list(set(old_skill))

        with driver.session() as session:
            # Update skills for the employee in Neo4j
            session.run(
                """
                MATCH (e:Employee {EmpID: $employee_id})-[r:HAS_SKILL]->(s:Skill)
                DELETE r

                WITH e
                UNWIND $updated_skills AS skillName
                MERGE (s:Skill {Name: skillName})
                MERGE (e)-[:HAS_SKILL]->(s)
                """,
                employee_id=int(employee_id),
                updated_skills= updated_skills #['Project Management', 'Risk Assessment and Mitigation', 'Leadership and Team Building']
            )

            # If a new manager ID was found, update the supervisor relationship
            if new_manager_id is not None:
                session.run("""
                        MATCH (e:Employee {EmpID: $employee_id})-[r:SUPERVISED_BY]->(m:Employee)
                        DELETE r
                        WITH e
                        MATCH (newManager:Employee {EmpID: $new_manager_id})
                        MERGE (e)-[:SUPERVISED_BY]->(newManager)
                        """,
                        employee_id=int(employee_id),
                        new_manager_id=int(new_manager_id)
                )
                return jsonify({'result': updated_skills})
        
        return jsonify({'result': "Skills updated successfully."})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
