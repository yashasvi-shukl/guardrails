from langchain.chains import GraphCypherQAChain
from langchain_community.graphs import Neo4jGraph
from langchain_openai import ChatOpenAI
import os
from flask import Flask, jsonify, request
import yaml
from langchain_core.prompts.prompt import PromptTemplate
from neo4j import GraphDatabase

app = Flask(__name__)

# Load the YAML configuration file
with open('config.yaml', 'r') as file:
    config = yaml.safe_load(file)

os.environ['OPENAI_API_KEY'] = config['OPENAI_API_KEY']
llm = ChatOpenAI(model="gpt-4o-mini")

graph = Neo4jGraph(url=config['NEO4J_URI'], username=config['NEO4J_USER'], password=config['NEO4J_PASSWORD'])
graph.refresh_schema()


CYPHER_GENERATION_TEMPLATE = """Task:Generate Cypher statement to query a neo4j graph database.

Instructions:
Use only the provided relationship types and properties in the schema.
Do not use any other relationship types or properties that are not provided.
Schema:
{schema}
Note: Do not include any explanations or apologies in your responses.
Do not respond to any questions that might ask anything else than for you to construct a Cypher statement.
Do not include any text except the generated Cypher statement.

As skills and certification comprises of list of values, which generating the query always CONTAINS operator on the entity and ensure that query should always be case insensitive.
Examples: Here are a few examples of generated Cypher statements for particular questions:

    # Names of employee who are skilled in Python Programming?
    MATCH (e:Employee)-[:HAS_SKILL]->(s:Skill)
    WHERE toLower(s.Name) CONTAINS toLower('Python')
    RETURN e.Name


The question is:
{question}"""

CYPHER_GENERATION_PROMPT = PromptTemplate(
    input_variables=["schema", "question"], template=CYPHER_GENERATION_TEMPLATE
)

chain = GraphCypherQAChain.from_llm(
    llm = llm,
    graph=graph,
    top_k = 10,
    verbose=True,
    cypher_prompt=CYPHER_GENERATION_PROMPT,
    validate_cypher=True,
    use_function_response=True,
    allow_dangerous_requests=True,
)
# chain = GraphCypherQAChain.from_llm(
#     llm, graph=graph, verbose=True, top_k=5, return_intermediate_steps=True, return_direct=True
# )

driver = GraphDatabase.driver(config['NEO4J_URI'], auth=(config['NEO4J_USER'], config['NEO4J_PASSWORD']))

@app.route('/query', methods=['POST'])
def query_neo4j():
    data = request.json
    query = data.get('query')
    
    if not query:
        return jsonify({"error": "Query not provided"}), 400

    try:
        result = chain.invoke({"query": query})
        return jsonify({"result": result['result']})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/cypher_query', methods=['POST'])
def neo4j_cypher_query():
    data = request.json
    query = data.get('query')

    if not query:
        return jsonify({"error": "Query not provided"}), 400

    try:
        with driver.session() as session:
            result = session.run(query)
            result_list = [record.data() for record in result]
        return jsonify({"result": result_list}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.teardown_appcontext
def close_driver(exception=None):
    if driver:
        driver.close()


# @app.route('/cypher_query', methods = ['POST'])
# def neo4j_cypher_query():
#     data = request.json()
#     query = data.get('query')

#     if not query:
#         return jsonify({"error": "Query not provided"}), 400
    
#     try:
#         result = graph.query(query)
#         return jsonify({"result": result['result']})
    
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
            
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9050)
