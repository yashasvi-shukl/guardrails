from flask import Flask, request, jsonify
from neo4j import GraphDatabase
import yaml

app = Flask(__name__)

with open('config.yaml', 'r') as file:
    config = yaml.safe_load(file)

# Define the Neo4j connection details
NEO4J_URI = config['NEO4J_URI']
NEO4J_USER = config['NEO4J_USER']
NEO4J_PASSWORD = config['NEO4J_PASSWORD']

# Function to update the mentor relationship
def update_mentor_relationship(employee_id, new_mentor_id):
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
    with driver.session() as session:
        session.run(
            """
            MATCH (e:Employee {EmpID: $employee_id})-[r:MENTORED_BY]->(m:Employee)
            DELETE r
            WITH e
            MATCH (newMentor:Employee {EmpID: $new_mentor_id})
            MERGE (e)-[:MENTORED_BY]->(newMentor)
            """,
            employee_id=employee_id,
            new_mentor_id=new_mentor_id
        )
    driver.close()

# Flask endpoint to update mentor relationship
@app.route('/update-mentor', methods=['POST'])
def update_mentor():
    data = request.get_json()
    
    # Validate input data
    if 'employee_id' not in data or 'new_mentor_id' not in data:
        return jsonify({'error': 'employee_id and new_mentor_id are required'}), 400
    
    employee_id = data['employee_id']
    new_mentor_id = data['new_mentor_id']
    
    try:
        update_mentor_relationship(employee_id, new_mentor_id)
        return jsonify({'message': 'Mentor relationship updated successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run( host='0.0.0.0', port=9051)
