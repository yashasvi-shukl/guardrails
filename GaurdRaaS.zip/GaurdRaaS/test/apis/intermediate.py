# intermediate.py
import ray
from serve_app import ModelDeployment
from ray import serve

# Connect to the running Ray instance
ray.init(address="auto", ignore_reinit_error=True)

# a = ModelDeployment._deploy()
# @ray.remote
def process_request(request_data):
    # model_handle = ModelDeployment.get_handle()
    # serve.run(entrypoint, port=8265, host="0.0.0.0", route_prefix="/")
    entrypoint = ModelDeployment.bind()
    handle = serve.run(entrypoint)
    result_obj = [handle.power.remote(x) for x in request_data['val']]
    print("Results: ", result_obj)
    return [result.result() for result in result_obj] # result_obj.result()