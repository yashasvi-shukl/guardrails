curl -H 'Content-Type: application/json' \
      -d '{ }' \
      -X POST \
      http://localhost:5000/get_guardrails_metadata
      