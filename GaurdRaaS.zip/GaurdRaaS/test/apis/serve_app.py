# serve_app.py
import ray
from ray import serve


# Initialize Serve
serve.start()

class Model:
    def __init__(self):
        pass

    def predict(self, data):
        # Dummy predict function: Just returns the input data
        return {"result": data}

    def another_function(self, data):
        # Another function for demonstration
        return {"processed_data": data.upper()}

@serve.deployment(
    # specify the number of GPU's available; zero if it is run on cpu
    ray_actor_options={"num_cpus": 5},
    # the number of instances of the  deployment in the cluster
    autoscaling_config={"min_replicas": 1, "max_replicas": 3},
    # the concurrency of the deployment
    max_concurrent_queries=2,
)
class ModelDeployment:
    def __init__(self):
        self.model = Model()

    def power(self, x):
        print("Value is: ", x)
        ans = x*x
        print("Answer is: ", ans)
        return ans
    

# # Deploy the model
# # ModelDeployment.deploy()

# if __name__ == "__main__":
#     ray.init(ignore_reinit_error=True)
#     entrypoint = ModelDeployment.bind()
#     serve.run(entrypoint)
