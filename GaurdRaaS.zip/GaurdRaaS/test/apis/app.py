# flask_app.py
from flask import Flask, request, jsonify
import ray
from intermediate import process_request
from serve_app import ModelDeployment
from ray import serve

app = Flask(__name__)

# Connect to the running Ray instance
ray.init(address="auto", ignore_reinit_error=True)

@app.route('/invoke', methods=['POST'])
def invoke():
    # Get the input data from the request
    input_data = request.get_json()

    # Call the intermediate function for parallel processing
    
    result = process_request(input_data)

    # Return the result as a JSON response
    return jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    # entrypoint = ModelDeployment.bind()
    # handle = serve.run(entrypoint)
