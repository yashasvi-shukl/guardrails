

# Simply a way of indicating that the value is expected to be a url string.
Url = str

# Specification of the classifier label.
ClassifierLabel = str

# Classifier name
ClassifierName = str

